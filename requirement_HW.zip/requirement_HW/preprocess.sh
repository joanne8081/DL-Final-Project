sudo apt-get update
sudo apt-get upgrade
sudo apt-get install -y build-essential

# cuda 8.0 installation
wget https://developer.nvidia.com/compute/cuda/8.0/Prod2/local_installers/cuda-repo-ubuntu1604-8-0-local-ga2_8.0.61-1_amd64-deb -O cuda-repo-ubuntu1604-8-0-local-ga2_8.0.61-1_amd64.deb
sudo dpkg -i cuda-repo-ubuntu1604-8-0-local-ga2_8.0.61-1_amd64.deb
sudo apt-get update
sudo apt-get install -y cuda

#sudo nano /etc/environment
#should copy and paste :/usr/local/cuda-8.0/bin
#source /etc/environment

cat <<EOF >> ~/.bashrc
export CUDA_HOME=/usr/local/cuda-8.0
export LD_LIBRARY_PATH=\${CUDA_HOME}/lib64
export PATH=\${CUDA_HOME}/bin:\${PATH}
EOF
source ~/.bashrc
#The following two lines are for testing
cuda-install-samples-8.0.sh ~
cd ~/NVIDIA_CUDA-8.0_Samples/1_Utilities/deviceQuery
make
./deviceQuery
nvcc --version
nvidia-smi

# cuDNN 6.0 installation
# cuDNN run version
wget https://www.dropbox.com/s/m4vmuu5q1wri7n1/libcudnn6_6.0.21-1%2Bcuda8.0_amd64.deb
sudo mv /usr/lib/nvidia-384/libEGL.so.1 /usr/lib/nvidia-384/libEGL.so.1.org
sudo mv /usr/lib32/nvidia-384/libEGL.so.1 /usr/lib32/nvidia-384/libEGL.so.1.org
sudo ln -s /usr/lib/nvidia-384/libEGL.so.384.90 /usr/lib/nvidia-384/libEGL.so.1
sudo ln -s /usr/lib32/nvidia-384/libEGL.so.384.90 /usr/lib32/nvidia-384/libEGL.so.1
sudo dpkg -i libcudnn6_6.0.21-1+cuda8.0_amd64.deb
#cuDNN develop version
wget https://www.dropbox.com/s/wwh1quo1gczwx16/libcudnn6-dev_6.0.21-1%2Bcuda8.0_amd64.deb
sudo dpkg -i libcudnn6-dev_6.0.21-1+cuda8.0_amd64.deb
#cuDNN sample and code
wget https://www.dropbox.com/s/mk8euvhzlet1z50/libcudnn6-doc_6.0.21-1%2Bcuda8.0_amd64.deb
sudo dpkg -i libcudnn6-doc_6.0.21-1+cuda8.0_amd64.deb

cp -r /usr/src/cudnn_samples_v6/ $HOME
cd  $HOME/cudnn_samples_v6/mnistCUDNN
make clean && make
./mnistCUDNN

# copy to cuda-8.0
#wget https://www.dropbox.com/s/f347bqi09xi163p/cudnn-8.0-linux-x64-v6.0.tar
#tar -xvzf cudnn-8.0-linux-x64-v6.0.tar

# This is the set-up script for Google Cloud.
sudo apt-get update
sudo apt-get install -y libncurses5-dev
sudo apt-get install -y libjpeg8-dev
sudo apt-get install -y python-pip
pip install --upgrade pip

sh setup_virenv.sh
sh requirement.sh
sudo apt-get install -y xvfb