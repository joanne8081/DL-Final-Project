cd ~/
git clone https://github.com/fanhqme/PointSetGeneration.git
cd PointSetGeneration/demo
wget https://www.dropbox.com/s/5v47923zrr84sti/twobranch_v1.pkl
wget https://www.dropbox.com/s/6m1vo59cebm6xjz/twobranch_v2.pkl